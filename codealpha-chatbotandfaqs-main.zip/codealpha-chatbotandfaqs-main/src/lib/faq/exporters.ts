import type { ChatMessage } from "./types";
import { download } from "./csv";

export function conversationId(messages: ChatMessage[]): string {
  const seed = messages[0]?.createdAt ?? Date.now();
  return `CHAT-${(seed % 100000).toString().padStart(5, "0")}`;
}

function csvCell(v: string) {
  return `"${v.replace(/"/g, '""')}"`;
}

export function exportConversation(messages: ChatMessage[], format: "json" | "csv" | "txt") {
  const id = conversationId(messages);
  if (format === "json") {
    download(`${id}.json`, JSON.stringify({ conversationId: id, messages }, null, 2), "application/json");
    return;
  }
  if (format === "csv") {
    const rows = [
      ["timestamp", "role", "message", "confidence", "score"].join(","),
      ...messages.map((m) =>
        [
          csvCell(new Date(m.createdAt).toISOString()),
          csvCell(m.role),
          csvCell(m.content),
          csvCell(m.analysis?.confidence ?? ""),
          csvCell(m.analysis ? m.analysis.score.toFixed(3) : ""),
        ].join(","),
      ),
    ];
    download(`${id}.csv`, rows.join("\n"), "text/csv");
    return;
  }
  const text = [
    `Conversation ID: ${id}`,
    `Date: ${new Date().toLocaleString()}`,
    "",
    ...messages.map(
      (m) =>
        `[${new Date(m.createdAt).toLocaleTimeString()}] ${m.role === "user" ? "User" : "FAQenius AI"}: ${m.content}`,
    ),
  ].join("\n");
  download(`${id}.txt`, text, "text/plain");
}
