import { preprocess } from "./textProcessing";
import type { ChatMessage } from "./types";

const FOLLOW_UP_MARKERS = [
  "that", "it", "this", "those", "these", "there", "them", "they", "he", "she",
  "one", "same", "instead", "also", "then", "why", "how", "what", "where", "which",
];

/** A short query, or one leaning on pronouns, is treated as a follow-up. */
export function isFollowUp(raw: string): boolean {
  const words = raw.toLowerCase().replace(/[^a-z0-9\s]/g, " ").split(/\s+/).filter(Boolean);
  if (words.length === 0) return false;
  const contentTokens = preprocess(raw);
  if (contentTokens.length <= 2) return true;
  return words.length <= 6 && words.some((w) => FOLLOW_UP_MARKERS.includes(w));
}

/** The most recent user turns, used to expand a follow-up question. */
export function recentContext(messages: ChatMessage[], turns = 2): string {
  return [...messages]
    .filter((m) => m.role === "user")
    .slice(-turns)
    .map((m) => m.content)
    .join(" ");
}

export type ConversationSummary = {
  topics: { label: string; count: number }[];
  mainTopic: string;
  questions: number;
  avgConfidence: number;
  unresolved: string[];
  text: string;
};

export function summarizeConversation(messages: ChatMessage[]): ConversationSummary {
  const bots = messages.filter((m) => m.role === "bot" && m.analysis);
  const users = messages.filter((m) => m.role === "user");
  const counts = new Map<string, number>();
  const unresolved: string[] = [];
  let scoreSum = 0;

  for (const m of bots) {
    const a = m.analysis!;
    scoreSum += a.score;
    const label = a.topMatches[0]?.faq.category ?? "General";
    if (a.confidence === "low") unresolved.push(a.query);
    else counts.set(label, (counts.get(label) ?? 0) + 1);
  }
  for (const m of messages.filter((x) => x.role === "bot" && x.feedback === "down")) {
    if (m.analysis) unresolved.push(m.analysis.query);
  }

  const topics = [...counts.entries()]
    .map(([label, count]) => ({ label, count }))
    .sort((a, b) => b.count - a.count);
  const avgConfidence = bots.length ? scoreSum / bots.length : 0;
  const mainTopic = topics[0]?.label ?? "General";
  const asked = users.slice(0, 4).map((m) => m.content.replace(/\s+/g, " ").trim());

  const text = [
    `The user asked ${users.length} question${users.length === 1 ? "" : "s"}${
      asked.length ? ` about ${asked.join("; ")}` : ""
    }.`,
    `Main topic: ${mainTopic}.`,
    `Average confidence: ${Math.round(avgConfidence * 100)}%.`,
    unresolved.length
      ? `Unresolved: ${[...new Set(unresolved)].slice(0, 3).join("; ")}.`
      : "Nothing left unresolved.",
  ].join("\n");

  return {
    topics,
    mainTopic,
    questions: users.length,
    avgConfidence,
    unresolved: [...new Set(unresolved)],
    text,
  };
}
