export type IntentDef = { id: string; label: string; keywords: string[] };

export const INTENTS: IntentDef[] = [
  { id: "password_reset", label: "Password Reset", keywords: ["password", "reset", "forgot", "login", "credential"] },
  { id: "order_tracking", label: "Order Tracking", keywords: ["track", "order", "package", "parcel", "delivery", "where"] },
  { id: "payment_methods", label: "Payment Methods", keywords: ["payment", "pay", "upi", "card", "paypal", "wallet", "checkout"] },
  { id: "refund_request", label: "Refund Request", keywords: ["refund", "return", "money", "back", "cancel"] },
  { id: "shipping_info", label: "Shipping Information", keywords: ["shipping", "ship", "deliver", "courier", "international", "charge"] },
  { id: "account_support", label: "Account Support", keywords: ["account", "profile", "email", "delete", "signup", "register"] },
  { id: "technical_support", label: "Technical Support", keywords: ["error", "bug", "crash", "issue", "not", "working", "app", "problem"] },
  { id: "security", label: "Security", keywords: ["secure", "security", "privacy", "data", "encryption", "safe"] },
  { id: "subscription", label: "Subscription", keywords: ["subscription", "plan", "renew", "upgrade", "downgrade", "billing"] },
];

import { stem } from "./textProcessing";

const STEMMED = INTENTS.map((i) => ({ ...i, stems: i.keywords.map(stem) }));

export function detectIntent(tokens: string[]): { id: string; label: string; score: number } | null {
  let best: { id: string; label: string; score: number } | null = null;
  for (const intent of STEMMED) {
    const hits = tokens.filter((t) => intent.stems.includes(t)).length;
    if (hits === 0) continue;
    const score = hits / Math.max(1, Math.min(tokens.length, intent.stems.length));
    if (!best || score > best.score) best = { id: intent.id, label: intent.label, score };
  }
  return best;
}

export function intentLabel(id?: string | null): string | null {
  if (!id) return null;
  return INTENTS.find((i) => i.id === id)?.label ?? id;
}