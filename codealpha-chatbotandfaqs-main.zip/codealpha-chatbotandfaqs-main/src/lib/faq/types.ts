export type FAQ = {
  id: string;
  question: string;
  answer: string;
  category: string;
  keywords: string[];
  intent?: string | undefined;
  createdAt: number;
};

export type Confidence = "high" | "medium" | "low";

export type MatchAnalysis = {
  query: string;
  tokens: string[];
  intent: string | null;
  score: number;
  confidence: Confidence;
  topMatches: { faq: FAQ; score: number }[];
  contextUsed?: boolean | undefined;
  contextQuery?: string | undefined;
};

export type ChatMessage = {
  id: string;
  role: "user" | "bot";
  content: string;
  createdAt: number;
  analysis?: MatchAnalysis | undefined;
  faqId?: string | undefined;
  feedback?: "up" | "down" | null | undefined;
  related?: string[] | undefined;
};

export type Settings = {
  theme: "light" | "dark" | "system";
  highThreshold: number;
  mediumThreshold: number;
  typingAnimation: boolean;
  showAnalysis: boolean;
  contextMemory: boolean;
  saveHistory: boolean;
  autoSpeak: boolean;
  speechRate: number;
  language: "en-US" | "hi-IN" | "te-IN";
};

export type SupportTicket = {
  id: string;
  reference: string;
  name: string;
  email: string;
  question: string;
  category: string;
  priority: "low" | "normal" | "high";
  summary: string;
  createdAt: number;
  status: "open";
};

export type AnalyticsEvent = {
  id: string;
  query: string;
  faqId?: string | undefined;
  category?: string | undefined;
  score: number;
  confidence: Confidence;
  helpful?: boolean | undefined;
  createdAt: number;
};