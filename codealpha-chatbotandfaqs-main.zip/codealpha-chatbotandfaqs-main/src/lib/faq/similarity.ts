import type { Confidence, FAQ, MatchAnalysis } from "./types";
import { preprocess } from "./textProcessing";
import { detectIntent } from "./intents";

type Vector = Map<string, number>;

function termFreq(tokens: string[]): Vector {
  const tf: Vector = new Map();
  for (const t of tokens) tf.set(t, (tf.get(t) ?? 0) + 1);
  for (const [k, v] of tf) tf.set(k, v / tokens.length);
  return tf;
}

export type Corpus = {
  idf: Map<string, number>;
  docs: { faq: FAQ; vector: Vector; tokens: string[] }[];
};

function faqTokens(faq: FAQ): string[] {
  return preprocess([faq.question, faq.keywords.join(" "), faq.category].join(" "));
}

export function buildCorpus(faqs: FAQ[]): Corpus {
  const docTokens = faqs.map((faq) => ({ faq, tokens: faqTokens(faq) }));
  const df = new Map<string, number>();
  for (const d of docTokens) {
    for (const t of new Set(d.tokens)) df.set(t, (df.get(t) ?? 0) + 1);
  }
  const N = Math.max(1, docTokens.length);
  const idf = new Map<string, number>();
  for (const [t, c] of df) idf.set(t, Math.log((N + 1) / (c + 1)) + 1);

  const docs = docTokens.map(({ faq, tokens }) => ({
    faq,
    tokens,
    vector: toTfIdf(termFreq(tokens), idf),
  }));
  return { idf, docs };
}

function toTfIdf(tf: Vector, idf: Map<string, number>): Vector {
  const v: Vector = new Map();
  for (const [t, f] of tf) v.set(t, f * (idf.get(t) ?? Math.log(2) + 1));
  return v;
}

export function cosineSimilarity(a: Vector, b: Vector): number {
  let dot = 0;
  let na = 0;
  let nb = 0;
  for (const [, va] of a) na += va * va;
  for (const [t, vb] of b) {
    nb += vb * vb;
    const va = a.get(t);
    if (va) dot += va * vb;
  }
  if (!na || !nb) return 0;
  return dot / (Math.sqrt(na) * Math.sqrt(nb));
}

function jaccard(a: string[], b: string[]): number {
  const sa = new Set(a);
  const sb = new Set(b);
  if (!sa.size || !sb.size) return 0;
  let inter = 0;
  for (const t of sa) if (sb.has(t)) inter++;
  return inter / (sa.size + sb.size - inter);
}

export function classifyConfidence(
  score: number,
  high = 0.75,
  medium = 0.5,
): Confidence {
  if (score >= high) return "high";
  if (score >= medium) return "medium";
  return "low";
}

export function matchQuery(
  query: string,
  corpus: Corpus,
  thresholds: { high: number; medium: number } = { high: 0.75, medium: 0.5 },
  contextQuery?: string,
): MatchAnalysis {
  const tokens = preprocess(query);
  const contextTokens = contextQuery ? preprocess(contextQuery) : [];
  const matchTokens = contextTokens.length ? [...tokens, ...tokens, ...contextTokens] : tokens;
  const intent = detectIntent(matchTokens);
  const qVec = toTfIdf(termFreq(matchTokens.length ? matchTokens : ["_"]), corpus.idf);

  const scored = corpus.docs.map((doc) => {
    const cos = cosineSimilarity(qVec, doc.vector);
    const jac = jaccard(matchTokens, doc.tokens);
    const intentBoost =
      intent && doc.faq.intent === intent.id ? 0.12 * Math.min(1, intent.score + 0.4) : 0;
    const score = Math.min(1, 0.72 * cos + 0.28 * jac + intentBoost);
    return { faq: doc.faq, score };
  });

  scored.sort((a, b) => b.score - a.score);
  const top = scored.slice(0, 4);
  const best = top[0]?.score ?? 0;

  return {
    query,
    tokens,
    intent: intent?.id ?? null,
    score: best,
    confidence: classifyConfidence(best, thresholds.high, thresholds.medium),
    topMatches: top,
    contextUsed: contextTokens.length > 0,
    contextQuery: contextTokens.length ? contextQuery : undefined,
  };
}