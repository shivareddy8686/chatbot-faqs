import type { FAQ } from "./types";
import { uid } from "./storage";

function splitCsvLine(line: string): string[] {
  const out: string[] = [];
  let cur = "";
  let inQuotes = false;
  for (let i = 0; i < line.length; i++) {
    const c = line[i];
    if (inQuotes) {
      if (c === '"' && line[i + 1] === '"') {
        cur += '"';
        i++;
      } else if (c === '"') inQuotes = false;
      else cur += c;
    } else if (c === '"') inQuotes = true;
    else if (c === ",") {
      out.push(cur);
      cur = "";
    } else cur += c;
  }
  out.push(cur);
  return out.map((s) => s.trim());
}

export function parseFaqCsv(text: string): FAQ[] {
  const lines = text.split(/\r?\n/).filter((l) => l.trim().length > 0);
  if (lines.length === 0) return [];
  const header = splitCsvLine(lines[0]!).map((h) => h.toLowerCase());
  const idx = {
    question: header.indexOf("question"),
    answer: header.indexOf("answer"),
    category: header.indexOf("category"),
    keywords: header.indexOf("keywords"),
  };
  const hasHeader = idx.question !== -1 && idx.answer !== -1;
  const rows = hasHeader ? lines.slice(1) : lines;
  const cols = hasHeader ? idx : { question: 0, answer: 1, category: 2, keywords: 3 };

  const faqs: FAQ[] = [];
  for (const line of rows) {
    const parts = splitCsvLine(line);
    const question = parts[cols.question] ?? "";
    const answer = parts[cols.answer] ?? "";
    if (!question || !answer) continue;
    const keywords = (cols.keywords >= 0 ? (parts[cols.keywords] ?? "") : "")
      .split(/[,;|]/)
      .map((k) => k.trim())
      .filter(Boolean);
    faqs.push({
      id: uid(),
      question,
      answer,
      category: (cols.category >= 0 ? parts[cols.category] : "") || "General",
      keywords,
      createdAt: Date.now(),
    });
  }
  return faqs;
}

const esc = (v: string) => `"${String(v).replace(/"/g, '""')}"`;

export function faqsToCsv(faqs: FAQ[]): string {
  const rows = faqs.map((f) =>
    [f.question, f.answer, f.category, f.keywords.join(",")].map(esc).join(","),
  );
  return ["question,answer,category,keywords", ...rows].join("\n");
}

export function download(filename: string, content: string, type: string) {
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}