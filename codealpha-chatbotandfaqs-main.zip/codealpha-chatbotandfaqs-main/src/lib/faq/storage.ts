import type { AnalyticsEvent, ChatMessage, FAQ, Settings, SupportTicket } from "./types";
import { DEFAULT_FAQS } from "./faqData";

const KEYS = {
  faqs: "faqenius.faqs",
  chat: "faqenius.chat",
  settings: "faqenius.settings",
  analytics: "faqenius.analytics",
  tickets: "faqenius.tickets",
};

export const DEFAULT_SETTINGS: Settings = {
  theme: "system",
  highThreshold: 0.75,
  mediumThreshold: 0.5,
  typingAnimation: true,
  showAnalysis: true,
  contextMemory: true,
  saveHistory: true,
  autoSpeak: false,
  speechRate: 1,
  language: "en-US",
};

function read<T>(key: string, fallback: T): T {
  if (typeof window === "undefined") return fallback;
  try {
    const raw = window.localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

function write(key: string, value: unknown) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(key, JSON.stringify(value));
  } catch {
    /* quota */
  }
}

export const storage = {
  loadFaqs: () => read<FAQ[]>(KEYS.faqs, DEFAULT_FAQS),
  saveFaqs: (faqs: FAQ[]) => write(KEYS.faqs, faqs),
  loadChat: () => read<ChatMessage[]>(KEYS.chat, []),
  saveChat: (m: ChatMessage[]) => write(KEYS.chat, m),
  loadSettings: () => ({ ...DEFAULT_SETTINGS, ...read<Partial<Settings>>(KEYS.settings, {}) }),
  saveSettings: (s: Settings) => write(KEYS.settings, s),
  loadAnalytics: () => read<AnalyticsEvent[]>(KEYS.analytics, []),
  saveAnalytics: (a: AnalyticsEvent[]) => write(KEYS.analytics, a),
  loadTickets: () => read<SupportTicket[]>(KEYS.tickets, []),
  saveTickets: (t: SupportTicket[]) => write(KEYS.tickets, t),
  resetAll: () => {
    if (typeof window === "undefined") return;
    Object.values(KEYS).forEach((k) => window.localStorage.removeItem(k));
  },
};

export const uid = () =>
  `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;