import { preprocess } from "./textProcessing";
import { INTENTS, detectIntent, intentLabel } from "./intents";
import type { AnalyticsEvent, ChatMessage, FAQ } from "./types";

/** Cosine similarity over raw term-frequency vectors of two texts. */
export function textSimilarity(a: string, b: string): number {
  const ta = preprocess(a);
  const tb = preprocess(b);
  if (!ta.length || !tb.length) return 0;
  const va = new Map<string, number>();
  const vb = new Map<string, number>();
  ta.forEach((t) => va.set(t, (va.get(t) ?? 0) + 1));
  tb.forEach((t) => vb.set(t, (vb.get(t) ?? 0) + 1));
  let dot = 0;
  let na = 0;
  let nb = 0;
  for (const [, v] of va) na += v * v;
  for (const [t, v] of vb) {
    nb += v * v;
    dot += (va.get(t) ?? 0) * v;
  }
  return dot / (Math.sqrt(na) * Math.sqrt(nb) || 1);
}

export type DuplicateHit = { faq: FAQ; similarity: number };

export function findDuplicates(question: string, faqs: FAQ[], excludeId?: string, min = 0.55): DuplicateHit[] {
  if (question.trim().length < 4) return [];
  return faqs
    .filter((f) => f.id !== excludeId)
    .map((faq) => ({ faq, similarity: textSimilarity(question, faq.question) }))
    .filter((h) => h.similarity >= min)
    .sort((a, b) => b.similarity - a.similarity)
    .slice(0, 3);
}

const CATEGORY_HINTS: { category: string; terms: string[] }[] = [
  { category: "Orders", terms: ["order", "track", "packag", "parcel", "deliveri", "ship"] },
  { category: "Payments", terms: ["payment", "pay", "upi", "card", "wallet", "checkout", "invoic"] },
  { category: "Refunds", terms: ["refund", "return", "cancel", "money"] },
  { category: "Account", terms: ["account", "password", "login", "profil", "email", "signup"] },
  { category: "Security", terms: ["secur", "privaci", "data", "encrypt", "safe"] },
  { category: "Billing", terms: ["subscript", "plan", "renew", "upgrad", "bill"] },
  { category: "Technical", terms: ["error", "bug", "crash", "issu", "app", "problem"] },
];

export type FaqSuggestion = { category: string; intent: string | null; intentLabel: string | null; keywords: string[] };

/** Suggest category, intent and keywords for a draft FAQ. */
export function suggestFaqMeta(question: string, answer = ""): FaqSuggestion {
  const tokens = preprocess(`${question} ${answer}`);
  const qTokens = preprocess(question);
  const intent = detectIntent(qTokens.length ? qTokens : tokens);

  let category = "General";
  let bestHits = 0;
  for (const hint of CATEGORY_HINTS) {
    const hits = tokens.filter((t) => hint.terms.some((h) => t.startsWith(h))).length;
    if (hits > bestHits) {
      bestHits = hits;
      category = hint.category;
    }
  }
  if (bestHits === 0 && intent) {
    const map: Record<string, string> = {
      password_reset: "Account",
      order_tracking: "Orders",
      payment_methods: "Payments",
      refund_request: "Refunds",
      shipping_info: "Shipping",
      account_support: "Account",
      technical_support: "Technical",
      security: "Security",
      subscription: "Billing",
    };
    category = map[intent.id] ?? "General";
  }

  const freq = new Map<string, number>();
  for (const t of qTokens) freq.set(t, (freq.get(t) ?? 0) + 2);
  for (const t of tokens) freq.set(t, (freq.get(t) ?? 0) + 1);
  const keywords = [...freq.entries()]
    .sort((a, b) => b[1] - a[1])
    .slice(0, 6)
    .map(([t]) => t);

  return {
    category,
    intent: intent?.id ?? null,
    intentLabel: intent ? intentLabel(intent.id) : null,
    keywords,
  };
}

export type FaqHealth = {
  faq: FAQ;
  score: number;
  uses: number;
  helpful: number;
  notHelpful: number;
  avgConfidence: number;
  issues: string[];
};

export function faqHealth(faqs: FAQ[], events: AnalyticsEvent[], messages: ChatMessage[]): FaqHealth[] {
  const feedbackByFaq = new Map<string, { up: number; down: number }>();
  for (const m of messages) {
    if (m.role !== "bot" || !m.faqId || !m.feedback) continue;
    const rec = feedbackByFaq.get(m.faqId) ?? { up: 0, down: 0 };
    if (m.feedback === "up") rec.up++;
    else rec.down++;
    feedbackByFaq.set(m.faqId, rec);
  }

  return faqs
    .map((faq) => {
      const own = events.filter((e) => e.faqId === faq.id);
      const uses = own.length;
      const avgConfidence = uses ? own.reduce((s, e) => s + e.score, 0) / uses : 0;
      const fb = feedbackByFaq.get(faq.id) ?? { up: 0, down: 0 };
      const totalFb = fb.up + fb.down;
      const satisfaction = totalFb ? fb.up / totalFb : 0.8;
      const issues: string[] = [];

      let score = 60;
      score += Math.min(15, uses * 3);
      score += Math.round((satisfaction - 0.5) * 40);
      score += Math.round(avgConfidence * 20);
      if (faq.keywords.length === 0) {
        score -= 12;
        issues.push("No keywords");
      }
      if (!faq.intent) {
        score -= 6;
        issues.push("No intent mapped");
      }
      if (faq.answer.trim().length < 25) {
        score -= 10;
        issues.push("Very short answer");
      }
      if (fb.down > fb.up && totalFb > 0) issues.push("Negative feedback");
      if (uses === 0) issues.push("Never matched yet");

      return {
        faq,
        score: Math.max(0, Math.min(100, score)),
        uses,
        helpful: fb.up,
        notHelpful: fb.down,
        avgConfidence,
        issues,
      };
    })
    .sort((a, b) => a.score - b.score);
}

export type KbHealth = {
  total: number;
  duplicates: { a: FAQ; b: FAQ; similarity: number }[];
  emptyAnswers: FAQ[];
  missingKeywords: FAQ[];
  missingIntent: FAQ[];
  score: number;
};

export function knowledgeBaseHealth(faqs: FAQ[]): KbHealth {
  const duplicates: { a: FAQ; b: FAQ; similarity: number }[] = [];
  for (let i = 0; i < faqs.length; i++) {
    for (let j = i + 1; j < faqs.length; j++) {
      const a = faqs[i]!;
      const b = faqs[j]!;
      const similarity = textSimilarity(a.question, b.question);
      if (similarity >= 0.7) duplicates.push({ a, b, similarity });
    }
  }
  const emptyAnswers = faqs.filter((f) => f.answer.trim().length < 15);
  const missingKeywords = faqs.filter((f) => f.keywords.length === 0);
  const missingIntent = faqs.filter((f) => !f.intent);
  const penalties =
    duplicates.length * 4 + emptyAnswers.length * 5 + missingKeywords.length * 2 + missingIntent.length;
  const score = faqs.length === 0 ? 0 : Math.max(0, Math.min(100, 100 - penalties));
  return { total: faqs.length, duplicates, emptyAnswers, missingKeywords, missingIntent, score };
}

export type SuggestedFaq = { question: string; occurrences: number; variants: string[]; suggestion: FaqSuggestion };

/** Cluster unanswered / low-confidence queries into candidate new FAQs. */
export function suggestedFaqs(events: AnalyticsEvent[], threshold = 0.5): SuggestedFaq[] {
  const weak = events.filter((e) => e.confidence === "low" || e.score < threshold);
  const clusters: { rep: string; variants: string[] }[] = [];
  for (const e of weak) {
    const hit = clusters.find((c) => textSimilarity(c.rep, e.query) >= 0.6);
    if (hit) hit.variants.push(e.query);
    else clusters.push({ rep: e.query, variants: [e.query] });
  }
  return clusters
    .map((c) => ({
      question: c.rep,
      occurrences: c.variants.length,
      variants: [...new Set(c.variants)],
      suggestion: suggestFaqMeta(c.rep),
    }))
    .sort((a, b) => b.occurrences - a.occurrences)
    .slice(0, 6);
}

export const ALL_INTENTS = INTENTS;
