import type { FAQ } from "./types";

let n = 0;
const f = (
  question: string,
  answer: string,
  category: string,
  keywords: string,
  intent?: string,
): FAQ => ({
  id: `seed-${++n}`,
  question,
  answer,
  category,
  keywords: keywords.split(",").map((k) => k.trim()).filter(Boolean),
  intent,
  createdAt: Date.now(),
});

export const DEFAULT_FAQS: FAQ[] = [
  f("How can I reset my password?", "Go to Settings → Security → Reset Password, or use the \"Forgot password\" link on the sign-in screen. A reset link is emailed to you and stays valid for 30 minutes.", "Account", "password,reset,forgot,login", "password_reset"),
  f("How do I track my order?", "Open **My Orders** and select the order to see live tracking. You can also paste your tracking ID on the carrier's site. Tracking activates within 24 hours of dispatch.", "Orders", "order,tracking,package,where", "order_tracking"),
  f("What payment methods do you accept?", "We accept UPI, debit cards, credit cards, net banking, PayPal, and major digital wallets. All payments are processed over an encrypted gateway.", "Payments", "payment,upi,card,paypal,wallet", "payment_methods"),
  f("How long do refunds take?", "Refunds are approved within 2 business days of the returned item being received, and the amount reaches your original payment method in 5–7 business days.", "Payments", "refund,money back,return,time", "refund_request"),
  f("How do I request a refund?", "Open the order, choose **Request Refund**, pick a reason, and submit. You'll get a confirmation email with the return instructions.", "Payments", "refund,cancel,return,request", "refund_request"),
  f("Do you ship internationally?", "Yes, we ship to 60+ countries. International delivery takes 7–14 business days, and customs duties, when applicable, are payable by the recipient.", "Shipping", "shipping,international,delivery,country", "shipping_info"),
  f("What are the shipping charges?", "Standard shipping is free on orders above ₹999. Below that, a flat ₹79 applies. Express shipping is ₹199 anywhere in the country.", "Shipping", "shipping,charges,cost,free,fee", "shipping_info"),
  f("How do I change my email address?", "Go to Settings → Profile → Email, enter the new address and confirm it through the verification link we send you.", "Account", "email,change,profile,update", "account_support"),
  f("How do I delete my account?", "Settings → Privacy → Delete Account. Deletion is permanent after a 14-day grace period, during which signing back in cancels the request.", "Account", "delete,account,remove,close", "account_support"),
  f("The app keeps crashing, what should I do?", "Update to the latest version, clear the app cache, and restart your device. If the crash persists, send us the crash log from Settings → Help → Report a Problem.", "Technical", "crash,bug,error,app,not working", "technical_support"),
  f("Why can't I log in to my account?", "Check that your email is typed correctly and caps lock is off. After 5 failed attempts the account locks for 15 minutes. Resetting your password clears the lock instantly.", "Technical", "login,cannot,locked,signin,error", "technical_support"),
  f("Is my personal data secure?", "Yes. Data is encrypted in transit with TLS 1.3 and at rest with AES-256. We never sell personal data and run third-party security audits twice a year.", "Security", "security,data,privacy,encryption,safe", "security"),
  f("How do I enable two-factor authentication?", "Settings → Security → Two-Factor Authentication. Scan the QR code with any authenticator app and save your backup codes somewhere safe.", "Security", "2fa,two factor,authentication,otp", "security"),
  f("How do I upgrade my subscription plan?", "Go to Billing → Plans and pick a new plan. Upgrades apply immediately and you are charged only the prorated difference.", "Subscription", "subscription,upgrade,plan,billing", "subscription"),
  f("How do I cancel my subscription?", "Billing → Manage Subscription → Cancel. You keep access until the end of the current billing period and are not charged again.", "Subscription", "cancel,subscription,renew,stop", "subscription"),
  f("Can I change my delivery address after ordering?", "Yes, as long as the order hasn't been dispatched. Open the order and choose **Edit Address**; after dispatch, contact support to reroute the parcel.", "Orders", "address,change,delivery,order", "order_tracking"),
  f("How do I contact customer support?", "Use the in-app chat, email support@example.com, or call our helpline on weekdays 9am–7pm. Typical first response time is under 4 hours.", "Support", "contact,support,help,email,phone", "account_support"),
  f("Do you offer discounts for students?", "Yes, verified students get 25% off any annual plan. Verify your student ID at Billing → Student Discount.", "Payments", "discount,student,offer,coupon", "payment_methods"),
  f("What is your return policy?", "Unused items in original packaging can be returned within 30 days of delivery. Perishable and personalised items are not eligible.", "Orders", "return,policy,exchange,30 days", "refund_request"),
  f("How long does delivery take?", "Metro cities usually receive orders in 2–4 business days; other locations take 4–7 business days. Express delivery arrives next day where available.", "Shipping", "delivery,time,how long,fast", "shipping_info"),
];