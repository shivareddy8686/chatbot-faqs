import { createFileRoute } from "@tanstack/react-router";
import { FAQManager } from "@/components/faq/FAQManager";

export const Route = createFileRoute("/faqs")({
  head: () => ({
    meta: [
      { title: "FAQ Manager — FAQenius AI Knowledge Base" },
      {
        name: "description",
        content:
          "Add, edit, categorise and search FAQs, manage keywords and intents, and import or export FAQ datasets as CSV or JSON.",
      },
      { property: "og:title", content: "FAQ Manager — FAQenius AI Knowledge Base" },
      {
        property: "og:description",
        content: "Manage the chatbot knowledge base with CSV import and JSON export.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: FAQManager,
});