import { createFileRoute } from "@tanstack/react-router";
import { Playground } from "@/components/faq/Playground";

export const Route = createFileRoute("/playground")({
  head: () => ({
    meta: [
      { title: "AI Playground — FAQenius NLP Pipeline Explorer" },
      {
        name: "description",
        content:
          "Test the FAQenius AI retrieval pipeline: token preprocessing, intent detection, TF-IDF cosine scoring, top-5 FAQ ranking and confidence estimation.",
      },
      { property: "og:title", content: "AI Playground — FAQenius NLP Pipeline Explorer" },
      {
        property: "og:description",
        content: "Inspect every stage of the FAQ retrieval pipeline in real time.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Playground,
});
