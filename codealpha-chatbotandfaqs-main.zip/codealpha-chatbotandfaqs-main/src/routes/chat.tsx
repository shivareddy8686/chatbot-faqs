import { createFileRoute } from "@tanstack/react-router";
import { ChatWindow } from "@/components/faq/ChatWindow";

export const Route = createFileRoute("/chat")({
  head: () => ({
    meta: [
      { title: "AI Chat — FAQenius AI Chatbot" },
      {
        name: "description",
        content:
          "Ask questions in natural language and get instant FAQ answers matched with TF-IDF, cosine similarity and intent detection.",
      },
      { property: "og:title", content: "AI Chat — FAQenius AI Chatbot" },
      {
        property: "og:description",
        content: "Natural-language FAQ chat with confidence scores and live AI match analysis.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ChatWindow,
});