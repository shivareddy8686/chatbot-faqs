import { createFileRoute, Link } from "@tanstack/react-router";
import {
  BarChart3,
  BookOpen,
  Brain,
  Gauge,
  MessageSquare,
  Sparkles,
  Target,
  Type,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import heroImage from "@/assets/hero-ai.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "FAQenius AI — Intelligent NLP FAQ Chatbot" },
      {
        name: "description",
        content:
          "FAQenius AI answers natural-language questions using NLP preprocessing, TF-IDF vectorisation, cosine similarity, intent detection and confidence scoring.",
      },
      { property: "og:title", content: "FAQenius AI — Intelligent NLP FAQ Chatbot" },
      {
        property: "og:description",
        content:
          "An AI-powered FAQ chatbot with semantic matching, confidence scores and an analytics dashboard.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const FEATURES = [
  { icon: Type, title: "NLP preprocessing", text: "Normalisation, tokenisation, stop-word removal and stemming before matching." },
  { icon: Brain, title: "TF-IDF vectors", text: "Each FAQ becomes a weighted vector where informative terms carry more signal." },
  { icon: Target, title: "Cosine similarity", text: "Queries are ranked by the angle between their vector and each FAQ vector." },
  { icon: Gauge, title: "Confidence scoring", text: "High, medium or low — low-confidence answers ask you to rephrase instead." },
  { icon: Sparkles, title: "Intent detection", text: "Nine intents from password reset to refunds sharpen ambiguous matches." },
  { icon: BarChart3, title: "Usage analytics", text: "Track answered questions, popular categories and unanswered queries." },
];

const PIPELINE = [
  "User question",
  "Text cleaning",
  "Tokenisation",
  "Stop-word removal",
  "Stemming",
  "TF-IDF",
  "Cosine similarity",
  "Best FAQ + confidence",
];

function Index() {
  return (
    <div>
      <section className="relative overflow-hidden">
        <img
          src={heroImage}
          alt="Abstract network of chat bubbles representing AI question matching"
          width={1536}
          height={1024}
          className="absolute inset-0 size-full object-cover opacity-20 dark:opacity-30"
        />
        <div className="relative mx-auto max-w-4xl px-4 py-24 text-center">
          <span className="inline-flex items-center gap-2 rounded-full border border-border bg-card/70 px-3 py-1 text-xs font-medium backdrop-blur">
            <Sparkles className="size-3.5 text-primary" /> NLP · TF-IDF · Cosine similarity
          </span>
          <h1 className="mt-6 text-4xl font-bold sm:text-6xl">
            Intelligent FAQ answers, <span className="text-gradient">without keyword guessing</span>
          </h1>
          <p className="mx-auto mt-5 max-w-2xl text-base text-muted-foreground sm:text-lg">
            FAQenius AI understands questions written in your own words, ranks every FAQ by semantic
            similarity and shows exactly how it reached the answer.
          </p>
          <div className="mt-8 flex flex-wrap justify-center gap-3">
            <Button asChild size="lg">
              <Link to="/chat">
                <MessageSquare className="size-4" /> Start chatting
              </Link>
            </Button>
            <Button asChild size="lg" variant="outline">
              <Link to="/faqs">
                <BookOpen className="size-4" /> Manage FAQs
              </Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-16">
        <h2 className="text-2xl font-semibold">What powers the answers</h2>
        <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {FEATURES.map((f) => (
            <Card key={f.title} className="shadow-soft">
              <CardContent className="pt-6">
                <span className="grid size-10 place-items-center rounded-xl bg-accent">
                  <f.icon className="size-5 text-accent-foreground" />
                </span>
                <h3 className="mt-4 text-base font-semibold">{f.title}</h3>
                <p className="mt-1 text-sm text-muted-foreground">{f.text}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      <section className="border-y border-border bg-surface-gradient">
        <div className="mx-auto max-w-6xl px-4 py-16">
          <h2 className="text-2xl font-semibold">The matching pipeline</h2>
          <ol className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {PIPELINE.map((step, i) => (
              <li
                key={step}
                className="rounded-xl border border-border bg-card px-4 py-3 text-sm shadow-soft"
              >
                <span className="mr-2 text-xs font-semibold text-primary tabular-nums">
                  {String(i + 1).padStart(2, "0")}
                </span>
                {step}
              </li>
            ))}
          </ol>
        </div>
      </section>

      <footer className="mx-auto max-w-6xl px-4 py-10 text-sm text-muted-foreground">
        Built by Duggim Praharsha · Data stays in your browser via localStorage.
      </footer>
    </div>
  );
}
