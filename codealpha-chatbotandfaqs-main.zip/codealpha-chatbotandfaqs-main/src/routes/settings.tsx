import { createFileRoute } from "@tanstack/react-router";
import { SettingsPage } from "@/components/faq/SettingsPage";

export const Route = createFileRoute("/settings")({
  head: () => ({
    meta: [
      { title: "Settings — FAQenius AI Preferences" },
      {
        name: "description",
        content:
          "Customise theme, confidence thresholds, chat behaviour and manage locally stored FAQ, chat and analytics data.",
      },
      { property: "og:title", content: "Settings — FAQenius AI Preferences" },
      {
        property: "og:description",
        content: "Tune similarity thresholds, theme and local data for the FAQ chatbot.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: SettingsPage,
});