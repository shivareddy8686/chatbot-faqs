import { createFileRoute } from "@tanstack/react-router";
import { Dashboard } from "@/components/faq/Dashboard";

export const Route = createFileRoute("/dashboard")({
  head: () => ({
    meta: [
      { title: "Analytics Dashboard — FAQenius AI" },
      {
        name: "description",
        content:
          "Track FAQ chatbot usage: questions answered, average similarity confidence, popular categories and unanswered questions.",
      },
      { property: "og:title", content: "Analytics Dashboard — FAQenius AI" },
      {
        property: "og:description",
        content: "Chatbot performance metrics, confidence distribution and most asked FAQs.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Dashboard,
});