import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { DEFAULT_FAQS } from "@/lib/faq/faqData";
import { storage, uid, DEFAULT_SETTINGS } from "@/lib/faq/storage";
import { buildCorpus, matchQuery } from "@/lib/faq/similarity";
import type {
  AnalyticsEvent,
  ChatMessage,
  FAQ,
  MatchAnalysis,
  Settings,
  SupportTicket,
} from "@/lib/faq/types";
import { isFollowUp, recentContext } from "@/lib/faq/conversation";

type Ctx = {
  ready: boolean;
  faqs: FAQ[];
  messages: ChatMessage[];
  events: AnalyticsEvent[];
  settings: Settings;
  addFaq: (f: Omit<FAQ, "id" | "createdAt">) => void;
  updateFaq: (id: string, f: Partial<FAQ>) => void;
  deleteFaq: (id: string) => void;
  importFaqs: (f: FAQ[], replace: boolean) => void;
  resetFaqs: () => void;
  tickets: SupportTicket[];
  ask: (query: string) => MatchAnalysis;
  addTicket: (t: Omit<SupportTicket, "id" | "reference" | "createdAt" | "status">) => SupportTicket;
  pushMessages: (m: ChatMessage[]) => void;
  setFeedback: (id: string, value: "up" | "down") => void;
  clearChat: () => void;
  updateSettings: (s: Partial<Settings>) => void;
  resetEverything: () => void;
};

const FaqContext = createContext<Ctx | null>(null);

export function FaqStoreProvider({ children }: { children: ReactNode }) {
  const [ready, setReady] = useState(false);
  const [faqs, setFaqs] = useState<FAQ[]>(DEFAULT_FAQS);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [events, setEvents] = useState<AnalyticsEvent[]>([]);
  const [settings, setSettings] = useState<Settings>(DEFAULT_SETTINGS);
  const [tickets, setTickets] = useState<SupportTicket[]>([]);

  useEffect(() => {
    setFaqs(storage.loadFaqs());
    setMessages(storage.loadChat());
    setEvents(storage.loadAnalytics());
    setSettings(storage.loadSettings());
    setTickets(storage.loadTickets());
    setReady(true);
  }, []);

  useEffect(() => {
    if (ready) storage.saveFaqs(faqs);
  }, [faqs, ready]);
  useEffect(() => {
    if (ready) storage.saveChat(settings.saveHistory ? messages : []);
  }, [messages, ready, settings.saveHistory]);
  useEffect(() => {
    if (ready) storage.saveTickets(tickets);
  }, [tickets, ready]);
  useEffect(() => {
    if (ready) storage.saveAnalytics(events);
  }, [events, ready]);
  useEffect(() => {
    if (ready) storage.saveSettings(settings);
  }, [settings, ready]);

  // theme
  useEffect(() => {
    if (typeof window === "undefined") return;
    const apply = () => {
      const prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
      const dark = settings.theme === "dark" || (settings.theme === "system" && prefersDark);
      document.documentElement.classList.toggle("dark", dark);
    };
    apply();
    const mq = window.matchMedia("(prefers-color-scheme: dark)");
    mq.addEventListener("change", apply);
    return () => mq.removeEventListener("change", apply);
  }, [settings.theme]);

  const messagesRef = useRef<ChatMessage[]>([]);
  useEffect(() => {
    messagesRef.current = messages;
  }, [messages]);

  const corpus = useMemo(() => buildCorpus(faqs), [faqs]);

  const ask = useCallback(
    (query: string) => {
      const context =
        settings.contextMemory && isFollowUp(query) ? recentContext(messagesRef.current) : undefined;
      const analysis = matchQuery(
        query,
        corpus,
        { high: settings.highThreshold, medium: settings.mediumThreshold },
        context || undefined,
      );
      const best = analysis.topMatches[0];
      setEvents((prev) => [
        ...prev,
        {
          id: uid(),
          query,
          faqId: analysis.confidence === "low" ? undefined : best?.faq.id,
          category: analysis.confidence === "low" ? undefined : best?.faq.category,
          score: analysis.score,
          confidence: analysis.confidence,
          createdAt: Date.now(),
        },
      ]);
      return analysis;
    },
    [corpus, settings.highThreshold, settings.mediumThreshold, settings.contextMemory],
  );

  const value: Ctx = {
    ready,
    faqs,
    messages,
    events,
    settings,
    tickets,
    addTicket: (t) => {
      const ticket: SupportTicket = {
        ...t,
        id: uid(),
        reference: `TKT-${Math.floor(1000 + Math.random() * 9000)}`,
        createdAt: Date.now(),
        status: "open",
      };
      setTickets((prev) => [ticket, ...prev]);
      return ticket;
    },
    addFaq: (f) => setFaqs((prev) => [{ ...f, id: uid(), createdAt: Date.now() }, ...prev]),
    updateFaq: (id, patch) =>
      setFaqs((prev) => prev.map((f) => (f.id === id ? { ...f, ...patch } : f))),
    deleteFaq: (id) => setFaqs((prev) => prev.filter((f) => f.id !== id)),
    importFaqs: (imported, replace) =>
      setFaqs((prev) => (replace ? imported : [...imported, ...prev])),
    resetFaqs: () => setFaqs(DEFAULT_FAQS),
    ask,
    pushMessages: (m) => setMessages((prev) => [...prev, ...m]),
    setFeedback: (id, feedbackValue) => {
      setMessages((prev) =>
        prev.map((m) => (m.id === id ? { ...m, feedback: feedbackValue } : m)),
      );
      const msg = messages.find((m) => m.id === id);
      if (msg) {
        setEvents((prev) =>
          prev.map((e, i) =>
            i === prev.length - 1 || e.query === msg.analysis?.query
              ? { ...e, helpful: feedbackValue === "up" }
              : e,
          ),
        );
      }
    },
    clearChat: () => setMessages([]),
    updateSettings: (s) => setSettings((prev) => ({ ...prev, ...s })),
    resetEverything: () => {
      storage.resetAll();
      setFaqs(DEFAULT_FAQS);
      setMessages([]);
      setEvents([]);
      setTickets([]);
      setSettings(DEFAULT_SETTINGS);
    },
  };

  return <FaqContext.Provider value={value}>{children}</FaqContext.Provider>;
}

export function useFaqStore() {
  const ctx = useContext(FaqContext);
  if (!ctx) throw new Error("useFaqStore must be used inside FaqStoreProvider");
  return ctx;
}