import { useMemo, useRef, useState } from "react";
import { AlertTriangle, Download, Pencil, Plus, Search, Sparkles, Trash2, Upload } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useFaqStore } from "@/hooks/useFaqStore";
import { INTENTS } from "@/lib/faq/intents";
import { download, faqsToCsv, parseFaqCsv } from "@/lib/faq/csv";
import { findDuplicates, suggestFaqMeta } from "@/lib/faq/insights";
import type { FAQ } from "@/lib/faq/types";

type Draft = { question: string; answer: string; category: string; keywords: string; intent: string };

const EMPTY: Draft = { question: "", answer: "", category: "General", keywords: "", intent: "none" };

export function FAQManager() {
  const { faqs, addFaq, updateFaq, deleteFaq, importFaqs } = useFaqStore();
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("all");
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<FAQ | null>(null);
  const [draft, setDraft] = useState<Draft>(EMPTY);
  const fileRef = useRef<HTMLInputElement>(null);
  const [forceCreate, setForceCreate] = useState(false);

  const duplicates = useMemo(
    () => findDuplicates(draft.question, faqs, editing?.id),
    [draft.question, faqs, editing],
  );

  const applySuggestions = () => {
    const s = suggestFaqMeta(draft.question, draft.answer);
    setDraft((d) => ({
      ...d,
      category: s.category,
      intent: s.intent ?? "none",
      keywords: s.keywords.join(", "),
    }));
    toast.success(`Suggested category "${s.category}"${s.intentLabel ? ` and intent "${s.intentLabel}"` : ""}`);
  };

  const categories = useMemo(
    () => Array.from(new Set(faqs.map((f) => f.category))).sort(),
    [faqs],
  );

  const filtered = useMemo(() => {
    const q = query.toLowerCase().trim();
    return faqs.filter(
      (f) =>
        (category === "all" || f.category === category) &&
        (!q ||
          f.question.toLowerCase().includes(q) ||
          f.answer.toLowerCase().includes(q) ||
          f.keywords.join(" ").toLowerCase().includes(q)),
    );
  }, [faqs, query, category]);

  const openNew = () => {
    setEditing(null);
    setDraft(EMPTY);
    setForceCreate(false);
    setOpen(true);
  };

  const openEdit = (faq: FAQ) => {
    setEditing(faq);
    setDraft({
      question: faq.question,
      answer: faq.answer,
      category: faq.category,
      keywords: faq.keywords.join(", "),
      intent: faq.intent ?? "none",
    });
    setForceCreate(false);
    setOpen(true);
  };

  const save = () => {
    if (!draft.question.trim() || !draft.answer.trim()) {
      toast.error("Question and answer are required");
      return;
    }
    if (!editing && duplicates.length > 0 && !forceCreate) {
      setForceCreate(true);
      toast.warning("A very similar FAQ already exists — press save again to create anyway");
      return;
    }
    const payload = {
      question: draft.question.trim(),
      answer: draft.answer.trim(),
      category: draft.category.trim() || "General",
      keywords: draft.keywords.split(",").map((k) => k.trim()).filter(Boolean),
      intent: draft.intent === "none" ? undefined : draft.intent,
    };
    if (editing) {
      updateFaq(editing.id, payload);
      toast.success("FAQ updated");
    } else {
      addFaq(payload);
      toast.success("FAQ added");
    }
    setOpen(false);
    setForceCreate(false);
  };

  const onImport = async (file: File) => {
    const text = await file.text();
    const parsed = parseFaqCsv(text);
    if (parsed.length === 0) {
      toast.error("No valid rows found. Expected: question,answer,category,keywords");
      return;
    }
    importFaqs(parsed, false);
    toast.success(`Imported ${parsed.length} FAQs`);
  };

  return (
    <div className="mx-auto max-w-6xl px-4 py-8">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold">FAQ Manager</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            {faqs.length} FAQs in the knowledge base — stored in your browser.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <input
            ref={fileRef}
            type="file"
            accept=".csv,text/csv"
            className="hidden"
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) void onImport(file);
              e.target.value = "";
            }}
          />
          <Button variant="outline" onClick={() => fileRef.current?.click()}>
            <Upload className="size-4" /> Import CSV
          </Button>
          <Button
            variant="outline"
            onClick={() => download("faqs.csv", faqsToCsv(faqs), "text/csv")}
          >
            <Download className="size-4" /> CSV
          </Button>
          <Button
            variant="outline"
            onClick={() =>
              download("faqs.json", JSON.stringify(faqs, null, 2), "application/json")
            }
          >
            <Download className="size-4" /> JSON
          </Button>
          <Button onClick={openNew}>
            <Plus className="size-4" /> Add FAQ
          </Button>
        </div>
      </div>

      <div className="mt-6 flex flex-wrap gap-3">
        <div className="relative min-w-60 flex-1">
          <Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search questions, answers or keywords…"
            className="pl-9"
          />
        </div>
        <Select value={category} onValueChange={setCategory}>
          <SelectTrigger className="w-48">
            <SelectValue placeholder="Category" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All categories</SelectItem>
            {categories.map((c) => (
              <SelectItem key={c} value={c}>
                {c}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="mt-5 grid gap-3">
        {filtered.length === 0 && (
          <p className="py-10 text-center text-sm text-muted-foreground">No FAQs match your filters.</p>
        )}
        {filtered.map((faq) => (
          <Card key={faq.id} className="shadow-soft">
            <CardContent className="flex flex-col gap-2 pt-6 sm:flex-row sm:items-start">
              <div className="flex-1">
                <div className="flex flex-wrap items-center gap-2">
                  <h2 className="text-base font-semibold">{faq.question}</h2>
                  <span className="rounded-full bg-accent px-2 py-0.5 text-xs text-accent-foreground">
                    {faq.category}
                  </span>
                </div>
                <p className="mt-1 text-sm text-muted-foreground">{faq.answer}</p>
                {faq.keywords.length > 0 && (
                  <div className="mt-2 flex flex-wrap gap-1">
                    {faq.keywords.map((k) => (
                      <span key={k} className="rounded-md bg-muted px-1.5 py-0.5 text-xs">
                        {k}
                      </span>
                    ))}
                  </div>
                )}
              </div>
              <div className="flex gap-1">
                <Button variant="ghost" size="icon" aria-label="Edit" onClick={() => openEdit(faq)}>
                  <Pencil className="size-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  aria-label="Delete"
                  onClick={() => {
                    deleteFaq(faq.id);
                    toast.success("FAQ deleted");
                  }}
                >
                  <Trash2 className="size-4 text-destructive" />
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editing ? "Edit FAQ" : "Add FAQ"}</DialogTitle>
            <DialogDescription>
              Keywords and intent improve TF-IDF matching accuracy.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-3">
            <div className="grid gap-1.5">
              <Label htmlFor="q">Question</Label>
              <Input
                id="q"
                value={draft.question}
                onChange={(e) => setDraft({ ...draft, question: e.target.value })}
              />
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="a">Answer</Label>
              <Textarea
                id="a"
                rows={4}
                value={draft.answer}
                onChange={(e) => setDraft({ ...draft, answer: e.target.value })}
              />
            </div>
            <div className="grid gap-3 sm:grid-cols-2">
              <div className="grid gap-1.5">
                <Label htmlFor="c">Category</Label>
                <Input
                  id="c"
                  value={draft.category}
                  onChange={(e) => setDraft({ ...draft, category: e.target.value })}
                />
              </div>
              <div className="grid gap-1.5">
                <Label htmlFor="i">Intent</Label>
                <Select
                  value={draft.intent}
                  onValueChange={(v) => setDraft({ ...draft, intent: v })}
                >
                  <SelectTrigger id="i">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">No intent</SelectItem>
                    {INTENTS.map((i) => (
                      <SelectItem key={i.id} value={i.id}>
                        {i.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid gap-1.5">
              <div className="flex items-center justify-between">
                <Label htmlFor="k">Keywords (comma separated)</Label>
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  disabled={!draft.question.trim()}
                  onClick={applySuggestions}
                >
                  <Sparkles className="size-3.5" /> AI suggest
                </Button>
              </div>
              <Input
                id="k"
                value={draft.keywords}
                onChange={(e) => setDraft({ ...draft, keywords: e.target.value })}
              />
            </div>
          </div>
          {duplicates.length > 0 && (
            <div className="rounded-xl border border-border bg-muted/50 p-3 text-xs">
              <div className="flex items-center gap-2 font-medium text-foreground">
                <AlertTriangle className="size-3.5 text-primary" />
                Similar FAQ{duplicates.length > 1 ? "s" : ""} already exist
              </div>
              <ul className="mt-2 space-y-2">
                {duplicates.map((d) => (
                  <li key={d.faq.id} className="flex items-center gap-2">
                    <span className="flex-1 truncate">{d.faq.question}</span>
                    <span className="tabular-nums">{Math.round(d.similarity * 100)}%</span>
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        setOpen(false);
                        openEdit(d.faq);
                      }}
                    >
                      Use existing
                    </Button>
                  </li>
                ))}
              </ul>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button onClick={save}>
              {editing ? "Save changes" : forceCreate ? "Create anyway" : "Add FAQ"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}