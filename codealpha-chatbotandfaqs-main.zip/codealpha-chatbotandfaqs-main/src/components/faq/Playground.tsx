import { useMemo, useState } from "react";
import { FlaskConical, Play } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ConfidenceBadge } from "./ConfidenceBadge";
import { useFaqStore } from "@/hooks/useFaqStore";
import { buildCorpus, matchQuery } from "@/lib/faq/similarity";
import { preprocess, tokenize } from "@/lib/faq/textProcessing";
import { intentLabel } from "@/lib/faq/intents";

const SAMPLES = ["Where is my package?", "Can I pay with UPI?", "I forgot my password", "How do refunds work?"];

export function Playground() {
  const { faqs, settings } = useFaqStore();
  const [query, setQuery] = useState("");
  const [ran, setRan] = useState("");

  const corpus = useMemo(() => buildCorpus(faqs), [faqs]);
  const result = useMemo(() => {
    if (!ran.trim()) return null;
    const analysis = matchQuery(ran, corpus, {
      high: settings.highThreshold,
      medium: settings.mediumThreshold,
    });
    return {
      analysis,
      raw: tokenize(ran),
      processed: preprocess(ran),
      top5: analysis.topMatches.slice(0, 5),
    };
  }, [ran, corpus, settings.highThreshold, settings.mediumThreshold]);

  return (
    <div className="mx-auto max-w-5xl px-4 py-8">
      <div className="flex items-center gap-2">
        <FlaskConical className="size-5 text-primary" />
        <h1 className="text-2xl font-semibold">AI Testing Playground</h1>
      </div>
      <p className="mt-1 text-sm text-muted-foreground">
        Inspect every stage of the retrieval pipeline: preprocessing, intent detection, TF-IDF
        scoring, ranking and confidence estimation.
      </p>

      <form
        className="mt-6 flex flex-wrap gap-2"
        onSubmit={(e) => {
          e.preventDefault();
          setRan(query);
        }}
      >
        <Input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Enter a test question…"
          className="min-w-60 flex-1"
        />
        <Button type="submit" disabled={!query.trim()}>
          <Play className="size-4" /> Run pipeline
        </Button>
      </form>
      <div className="mt-3 flex flex-wrap gap-2">
        {SAMPLES.map((s) => (
          <button
            key={s}
            onClick={() => {
              setQuery(s);
              setRan(s);
            }}
            className="rounded-full border border-border bg-secondary px-3 py-1 text-xs text-secondary-foreground hover:bg-accent hover:text-accent-foreground"
          >
            {s}
          </button>
        ))}
      </div>

      {!result && (
        <p className="mt-10 text-center text-sm text-muted-foreground">
          Run a question to see the full NLP trace.
        </p>
      )}

      {result && (
        <div className="mt-6 grid gap-4 lg:grid-cols-2">
          <Card className="shadow-soft">
            <CardHeader>
              <CardTitle className="text-base">1 · Text preprocessing</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 text-sm">
              <Row label="Raw tokens">
                <TokenList tokens={result.raw} muted />
              </Row>
              <Row label="Stop-words removed + stemmed">
                <TokenList tokens={result.processed} />
              </Row>
              <Row label="Vocabulary size">
                <span className="tabular-nums">{corpus.idf.size} terms across {faqs.length} FAQs</span>
              </Row>
            </CardContent>
          </Card>

          <Card className="shadow-soft">
            <CardHeader>
              <CardTitle className="text-base">2 · Intent & confidence</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 text-sm">
              <Row label="Detected intent">
                <span className="font-medium">
                  {intentLabel(result.analysis.intent) ?? "Not detected"}
                </span>
              </Row>
              <Row label="Best similarity">
                <span className="tabular-nums font-medium">{result.analysis.score.toFixed(4)}</span>
              </Row>
              <Row label="Confidence">
                <ConfidenceBadge
                  confidence={result.analysis.confidence}
                  score={result.analysis.score}
                />
              </Row>
              <Row label="Thresholds">
                <span className="tabular-nums text-muted-foreground">
                  high ≥ {settings.highThreshold.toFixed(2)} · medium ≥{" "}
                  {settings.mediumThreshold.toFixed(2)}
                </span>
              </Row>
            </CardContent>
          </Card>

          <Card className="shadow-soft lg:col-span-2">
            <CardHeader>
              <CardTitle className="text-base">3 · Top 5 FAQ matches</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {result.top5.map((m, i) => (
                <div key={m.faq.id} className="rounded-xl border border-border p-3">
                  <div className="flex items-center gap-2 text-sm">
                    <span className="text-muted-foreground tabular-nums">{i + 1}.</span>
                    <span className="flex-1 font-medium">{m.faq.question}</span>
                    <span className="tabular-nums">{(m.score * 100).toFixed(1)}%</span>
                  </div>
                  <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-muted">
                    <div
                      className="h-full rounded-full bg-hero-gradient"
                      style={{ width: `${Math.max(2, m.score * 100)}%` }}
                    />
                  </div>
                  <p className="mt-2 text-xs text-muted-foreground">{m.faq.answer}</p>
                </div>
              ))}
            </CardContent>
          </Card>

          <Card className="shadow-soft lg:col-span-2">
            <CardHeader>
              <CardTitle className="text-base">4 · Scoring formula</CardTitle>
            </CardHeader>
            <CardContent className="text-xs text-muted-foreground">
              <pre className="overflow-x-auto whitespace-pre-wrap rounded-lg bg-muted p-3 font-mono">
{`score = min(1, 0.72 × cosine(TF-IDF_query, TF-IDF_faq)
             + 0.28 × jaccard(query_tokens, faq_tokens)
             + intent_boost)

idf(t) = log((N + 1) / (df(t) + 1)) + 1`}
              </pre>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}

function Row({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <div className="text-xs text-muted-foreground">{label}</div>
      <div className="mt-1">{children}</div>
    </div>
  );
}

function TokenList({ tokens, muted }: { tokens: string[]; muted?: boolean }) {
  if (tokens.length === 0) return <span className="text-muted-foreground">—</span>;
  return (
    <div className="flex flex-wrap gap-1">
      {tokens.map((t, i) => (
        <span
          key={`${t}-${i}`}
          className={`rounded-md px-1.5 py-0.5 text-xs ${muted ? "bg-muted" : "bg-accent text-accent-foreground"}`}
        >
          {t}
        </span>
      ))}
    </div>
  );
}
