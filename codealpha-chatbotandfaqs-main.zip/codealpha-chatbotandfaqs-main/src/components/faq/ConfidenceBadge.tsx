import { cn } from "@/lib/utils";
import type { Confidence } from "@/lib/faq/types";

const MAP: Record<Confidence, { label: string; className: string }> = {
  high: { label: "High confidence", className: "bg-success/15 text-success border-success/30" },
  medium: { label: "Medium confidence", className: "bg-warning/15 text-warning border-warning/30" },
  low: { label: "Low confidence", className: "bg-destructive/15 text-destructive border-destructive/30" },
};

export function ConfidenceBadge({
  confidence,
  score,
  className,
}: {
  confidence: Confidence;
  score?: number;
  className?: string;
}) {
  const conf = MAP[confidence];
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-xs font-medium",
        conf.className,
        className,
      )}
    >
      <span className="size-1.5 rounded-full bg-current" />
      {conf.label}
      {score !== undefined && <span className="opacity-70">· {Math.round(score * 100)}%</span>}
    </span>
  );
}