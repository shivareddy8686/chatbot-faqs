import { Download, RotateCcw, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ThemeToggle } from "./ThemeToggle";
import { useFaqStore } from "@/hooks/useFaqStore";
import { download, faqsToCsv } from "@/lib/faq/csv";

export function SettingsPage() {
  const { settings, updateSettings, faqs, messages, events, clearChat, resetFaqs, resetEverything } =
    useFaqStore();

  return (
    <div className="mx-auto max-w-3xl px-4 py-8">
      <h1 className="text-2xl font-semibold">Settings</h1>
      <p className="mt-1 text-sm text-muted-foreground">
        Everything is stored locally in your browser — no accounts, no servers.
      </p>

      <div className="mt-6 grid gap-4">
        <Card className="shadow-soft">
          <CardHeader>
            <CardTitle className="text-base">Appearance</CardTitle>
            <CardDescription>Light, dark or follow your system.</CardDescription>
          </CardHeader>
          <CardContent>
            <ThemeToggle />
          </CardContent>
        </Card>

        <Card className="shadow-soft">
          <CardHeader>
            <CardTitle className="text-base">Confidence thresholds</CardTitle>
            <CardDescription>
              Similarity cut-offs used to classify answers as high, medium or low confidence.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <Label className="flex justify-between">
                High confidence ≥
                <span className="tabular-nums">{settings.highThreshold.toFixed(2)}</span>
              </Label>
              <Slider
                className="mt-3"
                min={0.3}
                max={0.95}
                step={0.01}
                value={[settings.highThreshold]}
                onValueChange={([v]) =>
                  updateSettings({
                    highThreshold: Math.max(v ?? 0.75, settings.mediumThreshold + 0.05),
                  })
                }
              />
            </div>
            <div>
              <Label className="flex justify-between">
                Medium confidence ≥
                <span className="tabular-nums">{settings.mediumThreshold.toFixed(2)}</span>
              </Label>
              <Slider
                className="mt-3"
                min={0.1}
                max={0.85}
                step={0.01}
                value={[settings.mediumThreshold]}
                onValueChange={([v]) =>
                  updateSettings({
                    mediumThreshold: Math.min(v ?? 0.5, settings.highThreshold - 0.05),
                  })
                }
              />
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-soft">
          <CardHeader>
            <CardTitle className="text-base">Chat preferences</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <Label htmlFor="typing">Typing animation</Label>
              <Switch
                id="typing"
                checked={settings.typingAnimation}
                onCheckedChange={(v) => updateSettings({ typingAnimation: v })}
              />
            </div>
            <div className="flex items-center justify-between">
              <Label htmlFor="analysis">Show AI match analysis</Label>
              <Switch
                id="analysis"
                checked={settings.showAnalysis}
                onCheckedChange={(v) => updateSettings({ showAnalysis: v })}
              />
            </div>
            <div className="flex items-center justify-between">
              <div>
                <Label htmlFor="context">Conversation memory</Label>
                <p className="text-xs text-muted-foreground">
                  Use previous turns to understand follow-ups like “how long does it take?”
                </p>
              </div>
              <Switch
                id="context"
                checked={settings.contextMemory}
                onCheckedChange={(v) => updateSettings({ contextMemory: v })}
              />
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-soft">
          <CardHeader>
            <CardTitle className="text-base">Voice &amp; language</CardTitle>
            <CardDescription>
              Speech recognition and speech synthesis run entirely in your browser.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between gap-4">
              <Label htmlFor="lang">Language</Label>
              <Select
                value={settings.language}
                onValueChange={(v) => updateSettings({ language: v as typeof settings.language })}
              >
                <SelectTrigger id="lang" className="w-44">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="en-US">English (US)</SelectItem>
                  <SelectItem value="hi-IN">हिन्दी (India)</SelectItem>
                  <SelectItem value="te-IN">తెలుగు (India)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center justify-between">
              <Label htmlFor="autospeak">Auto-speak answers</Label>
              <Switch
                id="autospeak"
                checked={settings.autoSpeak}
                onCheckedChange={(v) => updateSettings({ autoSpeak: v })}
              />
            </div>
            <div>
              <Label className="flex justify-between">
                Speech rate
                <span className="tabular-nums">{settings.speechRate.toFixed(2)}x</span>
              </Label>
              <Slider
                className="mt-3"
                min={0.5}
                max={2}
                step={0.05}
                value={[settings.speechRate]}
                onValueChange={([v]) => updateSettings({ speechRate: v ?? 1 })}
              />
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-soft">
          <CardHeader>
            <CardTitle className="text-base">Privacy</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <Label htmlFor="history">Save chat history</Label>
                <p className="text-xs text-muted-foreground">
                  When off, conversations disappear as soon as you close the tab.
                </p>
              </div>
              <Switch
                id="history"
                checked={settings.saveHistory}
                onCheckedChange={(v) => updateSettings({ saveHistory: v })}
              />
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-soft">
          <CardHeader>
            <CardTitle className="text-base">Data management</CardTitle>
            <CardDescription>
              {faqs.length} FAQs · {messages.length} chat messages · {events.length} logged queries
            </CardDescription>
          </CardHeader>
          <CardContent className="flex flex-wrap gap-2">
            <Button variant="outline" onClick={() => download("faqs.csv", faqsToCsv(faqs), "text/csv")}>
              <Download className="size-4" /> Export FAQs (CSV)
            </Button>
            <Button
              variant="outline"
              onClick={() =>
                download(
                  "faqenius-data.json",
                  JSON.stringify({ faqs, messages, events, settings }, null, 2),
                  "application/json",
                )
              }
            >
              <Download className="size-4" /> Export all (JSON)
            </Button>
            <Button
              variant="outline"
              onClick={() => {
                clearChat();
                toast.success("Chat history cleared");
              }}
            >
              <Trash2 className="size-4" /> Clear chat
            </Button>
            <Button
              variant="outline"
              onClick={() => {
                resetFaqs();
                toast.success("FAQs restored to defaults");
              }}
            >
              <RotateCcw className="size-4" /> Restore default FAQs
            </Button>
            <Button
              variant="destructive"
              onClick={() => {
                resetEverything();
                toast.success("All local data reset");
              }}
            >
              <Trash2 className="size-4" /> Reset everything
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}