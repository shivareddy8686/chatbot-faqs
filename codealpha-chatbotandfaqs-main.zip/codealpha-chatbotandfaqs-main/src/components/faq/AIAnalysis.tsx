import { Brain, ArrowRight } from "lucide-react";
import { ConfidenceBadge } from "./ConfidenceBadge";
import { intentLabel } from "@/lib/faq/intents";
import type { MatchAnalysis } from "@/lib/faq/types";

export function AIAnalysis({ analysis }: { analysis: MatchAnalysis }) {
  const best = analysis.topMatches[0];
  return (
    <div className="mt-3 rounded-xl border border-border bg-surface-gradient p-3 text-xs">
      <div className="mb-2 flex items-center gap-2 font-medium text-foreground">
        <Brain className="size-3.5 text-primary" />
        AI Match Analysis
      </div>
      <dl className="grid gap-2 sm:grid-cols-2">
        <div>
          <dt className="text-muted-foreground">Processed tokens</dt>
          <dd className="mt-1 flex flex-wrap gap-1">
            {analysis.tokens.length === 0 && <span className="text-muted-foreground">—</span>}
            {analysis.tokens.map((t) => (
              <span key={t} className="rounded-md bg-accent px-1.5 py-0.5 text-accent-foreground">
                {t}
              </span>
            ))}
          </dd>
        </div>
        <div>
          <dt className="text-muted-foreground">Detected intent</dt>
          <dd className="mt-1 font-medium">{intentLabel(analysis.intent) ?? "Not detected"}</dd>
        </div>
        <div className="sm:col-span-2">
          <dt className="text-muted-foreground">Best FAQ match</dt>
          <dd className="mt-1 font-medium">{best ? best.faq.question : "None"}</dd>
        </div>
        <div>
          <dt className="text-muted-foreground">Cosine similarity</dt>
          <dd className="mt-1 font-medium tabular-nums">{analysis.score.toFixed(3)}</dd>
        </div>
        <div>
          <dt className="text-muted-foreground">Confidence</dt>
          <dd className="mt-1">
            <ConfidenceBadge confidence={analysis.confidence} score={analysis.score} />
          </dd>
        </div>
      </dl>
      {analysis.topMatches.length > 1 && (
        <div className="mt-3 border-t border-border pt-2">
          <div className="mb-1 text-muted-foreground">FAQ ranking</div>
          <ul className="space-y-1">
            {analysis.topMatches.map((m, i) => (
              <li key={m.faq.id} className="flex items-center gap-2">
                <span className="text-muted-foreground tabular-nums">{i + 1}.</span>
                <span className="flex-1 truncate">{m.faq.question}</span>
                <ArrowRight className="size-3 text-muted-foreground" />
                <span className="tabular-nums font-medium">{Math.round(m.score * 100)}%</span>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}