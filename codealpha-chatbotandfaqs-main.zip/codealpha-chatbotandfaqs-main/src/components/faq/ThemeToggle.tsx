import { Moon, Sun, Laptop } from "lucide-react";
import { useFaqStore } from "@/hooks/useFaqStore";
import { cn } from "@/lib/utils";

const OPTIONS = [
  { value: "light", icon: Sun, label: "Light" },
  { value: "dark", icon: Moon, label: "Dark" },
  { value: "system", icon: Laptop, label: "System" },
] as const;

export function ThemeToggle() {
  const { settings, updateSettings } = useFaqStore();
  return (
    <div className="flex items-center gap-0.5 rounded-lg border border-border p-0.5">
      {OPTIONS.map((o) => (
        <button
          key={o.value}
          type="button"
          aria-label={`${o.label} theme`}
          onClick={() => updateSettings({ theme: o.value })}
          className={cn(
            "grid size-7 place-items-center rounded-md text-muted-foreground transition-colors hover:text-foreground",
            settings.theme === o.value && "bg-accent text-accent-foreground",
          )}
        >
          <o.icon className="size-3.5" />
        </button>
      ))}
    </div>
  );
}