import { useMemo, useState } from "react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { Activity, BookOpen, Check, Heart, MessageSquare, ThumbsUp, TrendingUp, X } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { faqHealth, knowledgeBaseHealth, suggestedFaqs } from "@/lib/faq/insights";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useFaqStore } from "@/hooks/useFaqStore";

export function Dashboard() {
  const { faqs, events, messages, tickets, addFaq } = useFaqStore();
  const [dismissed, setDismissed] = useState<string[]>([]);

  const health = useMemo(() => faqHealth(faqs, events, messages), [faqs, events, messages]);
  const kb = useMemo(() => knowledgeBaseHealth(faqs), [faqs]);
  const suggestions = useMemo(
    () => suggestedFaqs(events).filter((s) => !dismissed.includes(s.question)),
    [events, dismissed],
  );

  const bi = useMemo(() => {
    const total = events.length;
    const resolved = events.filter((e) => e.confidence !== "low").length;
    const up = messages.filter((m) => m.feedback === "up").length;
    const down = messages.filter((m) => m.feedback === "down").length;
    return {
      total,
      resolutionRate: total ? resolved / total : 0,
      escalationRate: total ? tickets.length / total : 0,
      satisfaction: up + down ? up / (up + down) : 0,
      coverage: total ? resolved / total : 0,
      tickets: tickets.length,
    };
  }, [events, messages, tickets]);

  const stats = useMemo(() => {
    const answered = events.length;
    const avg = answered ? events.reduce((s, e) => s + e.score, 0) / answered : 0;
    const helpful = messages.filter((m) => m.feedback === "up").length;
    const byFaq = new Map<string, number>();
    const byCategory = new Map<string, number>();
    const dist = { high: 0, medium: 0, low: 0 };
    const unanswered: string[] = [];
    for (const e of events) {
      dist[e.confidence]++;
      if (e.faqId) byFaq.set(e.faqId, (byFaq.get(e.faqId) ?? 0) + 1);
      if (e.category) byCategory.set(e.category, (byCategory.get(e.category) ?? 0) + 1);
      if (e.confidence === "low") unanswered.push(e.query);
    }
    const topFaqs = [...byFaq.entries()]
      .map(([id, count]) => ({ faq: faqs.find((f) => f.id === id), count }))
      .filter((x) => x.faq)
      .sort((a, b) => b.count - a.count)
      .slice(0, 5);
    const categories = [...byCategory.entries()]
      .map(([name, value]) => ({ name, value }))
      .sort((a, b) => b.value - a.value);
    return { answered, avg, helpful, topFaqs, categories, dist, unanswered: unanswered.slice(-8).reverse() };
  }, [events, faqs, messages]);

  const distData = [
    { name: "High", value: stats.dist.high, color: "var(--color-chart-2)" },
    { name: "Medium", value: stats.dist.medium, color: "var(--color-chart-3)" },
    { name: "Low", value: stats.dist.low, color: "var(--color-chart-4)" },
  ];

  const cards = [
    { label: "Total FAQs", value: faqs.length, icon: BookOpen },
    { label: "Questions answered", value: stats.answered, icon: MessageSquare },
    { label: "Avg. confidence", value: `${Math.round(stats.avg * 100)}%`, icon: TrendingUp },
    { label: "Helpful responses", value: stats.helpful, icon: ThumbsUp },
  ];

  return (
    <div className="mx-auto max-w-6xl px-4 py-8">
      <h1 className="text-2xl font-semibold">Analytics Dashboard</h1>
      <p className="mt-1 text-sm text-muted-foreground">
        Usage and matching performance, computed from your local chat history.
      </p>

      <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {cards.map((c) => (
          <Card key={c.label} className="shadow-soft">
            <CardContent className="flex items-center gap-4 pt-6">
              <span className="grid size-11 place-items-center rounded-xl bg-accent">
                <c.icon className="size-5 text-accent-foreground" />
              </span>
              <div>
                <div className="text-2xl font-semibold tabular-nums">{c.value}</div>
                <div className="text-xs text-muted-foreground">{c.label}</div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-2">
        <Card className="shadow-soft">
          <CardHeader>
            <CardTitle className="text-base">Popular categories</CardTitle>
          </CardHeader>
          <CardContent className="h-64">
            {stats.categories.length === 0 ? (
              <Empty />
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={stats.categories}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
                  <XAxis dataKey="name" fontSize={12} stroke="var(--color-muted-foreground)" />
                  <YAxis allowDecimals={false} fontSize={12} stroke="var(--color-muted-foreground)" />
                  <Tooltip
                    contentStyle={{
                      background: "var(--color-popover)",
                      border: "1px solid var(--color-border)",
                      borderRadius: 12,
                      color: "var(--color-popover-foreground)",
                    }}
                  />
                  <Bar dataKey="value" fill="var(--color-chart-1)" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>

        <Card className="shadow-soft">
          <CardHeader>
            <CardTitle className="text-base">Confidence distribution</CardTitle>
          </CardHeader>
          <CardContent className="h-64">
            {stats.answered === 0 ? (
              <Empty />
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={distData} dataKey="value" nameKey="name" innerRadius={50} outerRadius={85}>
                    {distData.map((d) => (
                      <Cell key={d.name} fill={d.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      background: "var(--color-popover)",
                      border: "1px solid var(--color-border)",
                      borderRadius: 12,
                      color: "var(--color-popover-foreground)",
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>

        <Card className="shadow-soft">
          <CardHeader>
            <CardTitle className="text-base">Most asked FAQs</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {stats.topFaqs.length === 0 && <Empty />}
            {stats.topFaqs.map(({ faq, count }) => (
              <div key={faq!.id} className="flex items-center gap-3 text-sm">
                <span className="flex-1 truncate">{faq!.question}</span>
                <span className="rounded-full bg-accent px-2 py-0.5 text-xs text-accent-foreground tabular-nums">
                  {count}
                </span>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card className="shadow-soft">
          <CardHeader>
            <CardTitle className="text-base">Unanswered questions</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {stats.unanswered.length === 0 && <Empty label="No low-confidence questions yet" />}
            {stats.unanswered.map((q, i) => (
              <div key={`${q}-${i}`} className="truncate rounded-lg bg-muted px-3 py-2 text-sm">
                {q}
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      <h2 className="mt-10 text-lg font-semibold">Business intelligence</h2>
      <div className="mt-3 grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
        {[
          { label: "Questions answered", value: bi.total },
          { label: "Resolution rate", value: `${Math.round(bi.resolutionRate * 100)}%` },
          { label: "Escalation rate", value: `${Math.round(bi.escalationRate * 100)}%` },
          { label: "User satisfaction", value: `${Math.round(bi.satisfaction * 100)}%` },
          { label: "Knowledge coverage", value: `${Math.round(bi.coverage * 100)}%` },
        ].map((c) => (
          <Card key={c.label} className="shadow-soft">
            <CardContent className="pt-6">
              <div className="text-2xl font-semibold tabular-nums">{c.value}</div>
              <div className="text-xs text-muted-foreground">{c.label}</div>
            </CardContent>
          </Card>
        ))}
      </div>
      <p className="mt-2 text-xs text-muted-foreground">
        Computed from your locally logged queries, feedback and support tickets — not sample data.
      </p>

      <div className="mt-6 grid gap-4 lg:grid-cols-2">
        <Card className="shadow-soft">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <Heart className="size-4 text-primary" /> FAQ health score
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {health.slice(0, 8).map((h) => (
              <div key={h.faq.id} className="text-sm">
                <div className="flex items-center gap-2">
                  <span aria-hidden>{h.score >= 80 ? "🟢" : h.score >= 60 ? "🟡" : "🔴"}</span>
                  <span className="flex-1 truncate">{h.faq.question}</span>
                  <span className="tabular-nums font-medium">{h.score}</span>
                </div>
                {h.issues.length > 0 && (
                  <div className="ml-6 mt-0.5 text-xs text-muted-foreground">
                    {h.issues.join(" · ")}
                  </div>
                )}
              </div>
            ))}
            {health.length === 0 && <Empty label="No FAQs yet" />}
          </CardContent>
        </Card>

        <Card className="shadow-soft">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <Activity className="size-4 text-primary" /> Knowledge base health
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-sm">
            <Metric label="FAQs" value={kb.total} />
            <Metric label="Possible duplicates" value={kb.duplicates.length} />
            <Metric label="Very short / empty answers" value={kb.emptyAnswers.length} />
            <Metric label="Missing keywords" value={kb.missingKeywords.length} />
            <Metric label="Missing intent" value={kb.missingIntent.length} />
            <div className="mt-3 border-t border-border pt-3">
              <div className="flex items-center justify-between">
                <span className="font-medium">Health score</span>
                <span className="tabular-nums font-semibold">{kb.score}%</span>
              </div>
              <div className="mt-2 h-2 overflow-hidden rounded-full bg-muted">
                <div className="h-full rounded-full bg-hero-gradient" style={{ width: `${kb.score}%` }} />
              </div>
            </div>
            {kb.duplicates.slice(0, 3).map((d) => (
              <div key={`${d.a.id}-${d.b.id}`} className="mt-2 rounded-lg bg-muted px-3 py-2 text-xs">
                <span className="font-medium">{Math.round(d.similarity * 100)}% similar:</span>{" "}
                {d.a.question} ↔ {d.b.question}
              </div>
            ))}
          </CardContent>
        </Card>

        <Card className="shadow-soft lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-base">AI-generated FAQ suggestions</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {suggestions.length === 0 && (
              <Empty label="No low-confidence question clusters to learn from yet" />
            )}
            {suggestions.map((s) => (
              <div key={s.question} className="rounded-xl border border-border p-3">
                <div className="flex flex-wrap items-center gap-2 text-sm">
                  <span className="flex-1 font-medium">“{s.question}”</span>
                  <span className="rounded-full bg-accent px-2 py-0.5 text-xs text-accent-foreground">
                    {s.occurrences} occurrence{s.occurrences === 1 ? "" : "s"}
                  </span>
                </div>
                <div className="mt-1 text-xs text-muted-foreground">
                  Suggested category: {s.suggestion.category}
                  {s.suggestion.intentLabel ? ` · intent: ${s.suggestion.intentLabel}` : ""} ·
                  keywords: {s.suggestion.keywords.join(", ") || "—"}
                </div>
                <div className="mt-2 flex gap-2">
                  <Button
                    size="sm"
                    onClick={() => {
                      addFaq({
                        question: s.question,
                        answer: "Draft answer — replace this in the FAQ Manager.",
                        category: s.suggestion.category,
                        keywords: s.suggestion.keywords,
                        intent: s.suggestion.intent ?? undefined,
                      });
                      setDismissed((d) => [...d, s.question]);
                      toast.success("Draft FAQ created — edit it in the FAQ Manager");
                    }}
                  >
                    <Check className="size-3.5" /> Approve
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => setDismissed((d) => [...d, s.question])}
                  >
                    <X className="size-3.5" /> Reject
                  </Button>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card className="shadow-soft lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-base">Support tickets ({tickets.length})</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {tickets.length === 0 && <Empty label="No escalations yet" />}
            {tickets.slice(0, 5).map((t) => (
              <div key={t.id} className="rounded-lg bg-muted px-3 py-2 text-sm">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="font-medium">{t.reference}</span>
                  <span className="flex-1 truncate">{t.question}</span>
                  <span className="rounded-full bg-accent px-2 py-0.5 text-xs text-accent-foreground">
                    {t.priority}
                  </span>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function Metric({ label, value }: { label: string; value: number }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-muted-foreground">{label}</span>
      <span className="tabular-nums font-medium">{value}</span>
    </div>
  );
}

function Empty({ label = "No data yet — start a chat" }: { label?: string }) {
  return (
    <div className="grid h-full place-items-center py-8 text-sm text-muted-foreground">{label}</div>
  );
}