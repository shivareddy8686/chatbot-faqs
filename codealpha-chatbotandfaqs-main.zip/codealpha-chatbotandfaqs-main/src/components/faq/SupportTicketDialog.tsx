import { useState } from "react";
import { toast } from "sonner";
import { LifeBuoy } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useFaqStore } from "@/hooks/useFaqStore";
import { summarizeConversation } from "@/lib/faq/conversation";
import type { SupportTicket } from "@/lib/faq/types";

export function SupportTicketDialog({
  question,
  trigger,
}: {
  question: string;
  trigger?: React.ReactNode;
}) {
  const { messages, addTicket } = useFaqStore();
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [q, setQ] = useState(question);
  const [category, setCategory] = useState("General");
  const [priority, setPriority] = useState<SupportTicket["priority"]>("normal");

  const summary = summarizeConversation(messages).text;

  const submit = () => {
    if (!name.trim() || !email.trim() || !q.trim()) {
      toast.error("Name, email and question are required");
      return;
    }
    const ticket = addTicket({ name, email, question: q, category, priority, summary });
    toast.success(`Ticket ${ticket.reference} created locally`);
    setOpen(false);
  };

  return (
    <Dialog
      open={open}
      onOpenChange={(v) => {
        setOpen(v);
        if (v) setQ(question);
      }}
    >
      <DialogTrigger asChild>
        {trigger ?? (
          <Button variant="outline" size="sm">
            <LifeBuoy className="size-3.5" /> Contact support
          </Button>
        )}
      </DialogTrigger>
      <DialogContent className="max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Submit a support request</DialogTitle>
          <DialogDescription>
            Your conversation summary is attached. Tickets are stored in this browser only.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-3">
          <div className="grid gap-3 sm:grid-cols-2">
            <div className="grid gap-1.5">
              <Label htmlFor="t-name">Name</Label>
              <Input id="t-name" value={name} onChange={(e) => setName(e.target.value)} />
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="t-email">Email</Label>
              <Input
                id="t-email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
          </div>
          <div className="grid gap-1.5">
            <Label htmlFor="t-q">Question</Label>
            <Textarea id="t-q" rows={3} value={q} onChange={(e) => setQ(e.target.value)} />
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            <div className="grid gap-1.5">
              <Label htmlFor="t-cat">Category</Label>
              <Input id="t-cat" value={category} onChange={(e) => setCategory(e.target.value)} />
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="t-pri">Priority</Label>
              <Select value={priority} onValueChange={(v) => setPriority(v as SupportTicket["priority"])}>
                <SelectTrigger id="t-pri">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="normal">Normal</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="grid gap-1.5">
            <Label>Attached conversation summary</Label>
            <pre className="max-h-32 overflow-auto whitespace-pre-wrap rounded-lg bg-muted p-3 text-xs text-muted-foreground">
              {summary}
            </pre>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => setOpen(false)}>
            Cancel
          </Button>
          <Button onClick={submit}>Create ticket</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
