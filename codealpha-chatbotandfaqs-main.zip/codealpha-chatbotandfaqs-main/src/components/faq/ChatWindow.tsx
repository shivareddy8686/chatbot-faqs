import { useEffect, useMemo, useRef, useState } from "react";
import {
  Bot,
  Copy,
  Download,
  FileText,
  Mic,
  MicOff,
  Pause,
  Play,
  RefreshCw,
  Send,
  Sparkles,
  Square,
  ThumbsDown,
  ThumbsUp,
  Trash2,
  User,
  Volume2,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ConfidenceBadge } from "./ConfidenceBadge";
import { AIAnalysis } from "./AIAnalysis";
import { SupportTicketDialog } from "./SupportTicketDialog";
import { useFaqStore } from "@/hooks/useFaqStore";
import { useSpeechOutput, useVoiceInput } from "@/hooks/useSpeech";
import { uid } from "@/lib/faq/storage";
import { summarizeConversation } from "@/lib/faq/conversation";
import { exportConversation, conversationId } from "@/lib/faq/exporters";
import type { ChatMessage, MatchAnalysis, Settings } from "@/lib/faq/types";
import { cn } from "@/lib/utils";

const SUGGESTIONS = [
  "Where is my package?",
  "Can I pay using UPI?",
  "I forgot my password",
  "How long do refunds take?",
  "Is my data secure?",
];

const LANGUAGES: { value: Settings["language"]; label: string }[] = [
  { value: "en-US", label: "English" },
  { value: "te-IN", label: "తెలుగు" },
  { value: "hi-IN", label: "हिन्दी" },
];

function buildAnswer(analysis: MatchAnalysis): { content: string; faqId?: string; related: string[] } {
  const best = analysis.topMatches[0];
  const related = analysis.topMatches
    .slice(1, 4)
    .filter((m) => m.score >= 0.2)
    .map((m) => m.faq.question);
  if (!best || analysis.confidence === "low") {
    return {
      content:
        "I'm not confident that I found the right answer. Try rephrasing with a few more specific words — or escalate the question to human support below.",
      related,
    };
  }
  const prefix = analysis.confidence === "medium" ? "This looks like the closest match I have:\n\n" : "";
  const contextNote = analysis.contextUsed ? "*(using our earlier conversation for context)*\n\n" : "";
  return { content: `${contextNote}${prefix}${best.faq.answer}`, faqId: best.faq.id, related };
}

function renderInline(text: string) {
  return text.split(/(\*\*[^*]+\*\*|\*[^*]+\*)/g).map((part, i) => {
    if (part.startsWith("**") && part.endsWith("**"))
      return <strong key={i}>{part.slice(2, -2)}</strong>;
    if (part.startsWith("*") && part.endsWith("*") && part.length > 2)
      return <em key={i}>{part.slice(1, -1)}</em>;
    return <span key={i}>{part}</span>;
  });
}

export function ChatWindow() {
  const {
    messages,
    pushMessages,
    clearChat,
    ask,
    setFeedback,
    settings,
    updateSettings,
    faqs,
    ready,
  } = useFaqStore();
  const [input, setInput] = useState("");
  const [typing, setTyping] = useState(false);
  const [showSummary, setShowSummary] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  const speech = useSpeechOutput(settings.speechRate, settings.language);
  const voice = useVoiceInput((text) => {
    setInput(text);
    window.setTimeout(() => send(text), 60);
  }, settings.language);

  const lastUserQuery = useMemo(
    () => [...messages].reverse().find((m) => m.role === "user")?.content ?? "",
    [messages],
  );
  const summary = useMemo(() => summarizeConversation(messages), [messages]);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, typing]);

  useEffect(() => {
    if (!typing) inputRef.current?.focus();
  }, [typing]);

  const send = (raw: string, replaceLast = false) => {
    const query = raw.trim();
    if (!query || typing) return;
    setInput("");
    const analysis = ask(query);
    const { content, faqId, related } = buildAnswer(analysis);

    const userMsg: ChatMessage = { id: uid(), role: "user", content: query, createdAt: Date.now() };
    const botMsg: ChatMessage = {
      id: uid(),
      role: "bot",
      content,
      createdAt: Date.now(),
      analysis,
      faqId,
      feedback: null,
      related,
    };

    if (!replaceLast) pushMessages([userMsg]);
    setTyping(true);
    window.setTimeout(
      () => {
        setTyping(false);
        pushMessages([botMsg]);
        if (settings.autoSpeak && speech.supported) speech.speak(botMsg.content, botMsg.id);
      },
      settings.typingAnimation ? 550 : 0,
    );
  };

  const copy = async (text: string) => {
    await navigator.clipboard.writeText(text);
    toast.success("Response copied");
  };

  return (
    <div className="mx-auto flex h-[calc(100vh-4rem)] max-w-4xl flex-col px-4">
      <div className="flex flex-wrap items-center justify-between gap-2 py-4">
        <div>
          <h1 className="text-xl font-semibold">AI Chat</h1>
          <p className="text-sm text-muted-foreground">
            {faqs.length} FAQs indexed · TF-IDF + cosine similarity
            {settings.contextMemory ? " · conversation memory on" : ""}
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Select
            value={settings.language}
            onValueChange={(v) => updateSettings({ language: v as Settings["language"] })}
          >
            <SelectTrigger className="h-9 w-32" aria-label="Voice language">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {LANGUAGES.map((l) => (
                <SelectItem key={l.value} value={l.value}>
                  {l.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowSummary((v) => !v)}
            disabled={messages.length === 0}
          >
            <FileText className="size-4" /> Summarise
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => exportConversation(messages, "json")}
            disabled={messages.length === 0}
          >
            <Download className="size-4" /> JSON
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => exportConversation(messages, "csv")}
            disabled={messages.length === 0}
          >
            <Download className="size-4" /> CSV
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => exportConversation(messages, "txt")}
            disabled={messages.length === 0}
          >
            <Download className="size-4" /> TXT
          </Button>
          <Button variant="outline" size="sm" onClick={clearChat} disabled={messages.length === 0}>
            <Trash2 className="size-4" /> Clear
          </Button>
        </div>
      </div>

      {showSummary && messages.length > 0 && (
        <div className="mb-3 rounded-2xl border border-border bg-surface-gradient p-4 text-sm">
          <div className="flex items-center gap-2 font-medium">
            <Sparkles className="size-4 text-primary" /> Conversation summary
            <span className="ml-auto text-xs text-muted-foreground">
              {conversationId(messages)}
            </span>
          </div>
          <p className="mt-2 whitespace-pre-wrap text-muted-foreground">{summary.text}</p>
          <div className="mt-3 flex flex-wrap gap-2 text-xs">
            <span className="rounded-full bg-accent px-2 py-0.5 text-accent-foreground">
              Main topic: {summary.mainTopic}
            </span>
            <span className="rounded-full bg-accent px-2 py-0.5 text-accent-foreground">
              Questions: {summary.questions}
            </span>
            <span className="rounded-full bg-accent px-2 py-0.5 text-accent-foreground">
              Avg confidence: {Math.round(summary.avgConfidence * 100)}%
            </span>
          </div>
        </div>
      )}

      <div className="flex-1 space-y-4 overflow-y-auto rounded-2xl border border-border bg-card p-4 shadow-soft">
        {ready && messages.length === 0 && (
          <div className="grid h-full place-items-center py-10 text-center">
            <div>
              <span className="mx-auto grid size-14 place-items-center rounded-2xl bg-hero-gradient shadow-glow">
                <Bot className="size-7 text-primary-foreground" />
              </span>
              <h2 className="mt-4 text-lg font-semibold">Ask me anything</h2>
              <p className="mx-auto mt-1 max-w-sm text-sm text-muted-foreground">
                I analyse your question with NLP preprocessing, TF-IDF vectorisation and cosine
                similarity — by keyboard or by voice.
              </p>
              <div className="mt-5 flex flex-wrap justify-center gap-2">
                {SUGGESTIONS.map((s) => (
                  <button
                    key={s}
                    onClick={() => send(s)}
                    className="rounded-full border border-border bg-secondary px-3 py-1.5 text-sm text-secondary-foreground transition-colors hover:bg-accent hover:text-accent-foreground"
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {messages.map((m) => (
          <div
            key={m.id}
            className={cn("flex gap-3", m.role === "user" ? "justify-end" : "justify-start")}
          >
            {m.role === "bot" && (
              <span className="mt-1 grid size-8 shrink-0 place-items-center rounded-xl bg-hero-gradient">
                <Bot className="size-4 text-primary-foreground" />
              </span>
            )}
            <div className={cn("max-w-[85%]", m.role === "user" && "order-first")}>
              <div
                className={cn(
                  "rounded-2xl px-4 py-3 text-sm leading-relaxed whitespace-pre-wrap",
                  m.role === "user"
                    ? "bg-primary text-primary-foreground"
                    : "border border-border bg-surface-gradient",
                )}
              >
                {renderInline(m.content)}
              </div>

              {m.role === "bot" && m.analysis && (
                <>
                  <div className="mt-2 flex flex-wrap items-center gap-2">
                    <ConfidenceBadge confidence={m.analysis.confidence} score={m.analysis.score} />
                    {m.analysis.contextUsed && (
                      <span className="rounded-full bg-accent px-2 py-0.5 text-xs text-accent-foreground">
                        follow-up context
                      </span>
                    )}
                    <Button variant="ghost" size="sm" onClick={() => copy(m.content)}>
                      <Copy className="size-3.5" /> Copy
                    </Button>
                    {speech.supported && (
                      <>
                        <Button variant="ghost" size="sm" onClick={() => speech.speak(m.content, m.id)}>
                          <Volume2 className="size-3.5" /> Read
                        </Button>
                        {speech.speaking && (
                          <>
                            <Button variant="ghost" size="sm" onClick={speech.pauseResume}>
                              {speech.paused ? <Play className="size-3.5" /> : <Pause className="size-3.5" />}
                            </Button>
                            <Button variant="ghost" size="sm" onClick={speech.stop}>
                              <Square className="size-3.5" />
                            </Button>
                          </>
                        )}
                      </>
                    )}
                    <Button variant="ghost" size="sm" onClick={() => send(m.analysis!.query, true)}>
                      <RefreshCw className="size-3.5" /> Regenerate
                    </Button>
                    <Button
                      variant={m.feedback === "up" ? "secondary" : "ghost"}
                      size="sm"
                      onClick={() => setFeedback(m.id, "up")}
                    >
                      <ThumbsUp className="size-3.5" />
                    </Button>
                    <Button
                      variant={m.feedback === "down" ? "secondary" : "ghost"}
                      size="sm"
                      onClick={() => setFeedback(m.id, "down")}
                    >
                      <ThumbsDown className="size-3.5" />
                    </Button>
                  </div>

                  {(m.analysis.confidence === "low" || m.feedback === "down") && (
                    <div className="mt-2 flex flex-wrap items-center gap-2 rounded-xl border border-border bg-muted/50 p-3 text-xs">
                      <span className="text-muted-foreground">
                        Not what you needed? Escalate to a human.
                      </span>
                      <SupportTicketDialog question={m.analysis.query} />
                      <Button variant="ghost" size="sm" onClick={() => send(m.analysis!.query, true)}>
                        <RefreshCw className="size-3.5" /> Try again
                      </Button>
                    </div>
                  )}

                  {m.related && m.related.length > 0 && (
                    <div className="mt-2">
                      <div className="mb-1 text-xs text-muted-foreground">
                        You might also want to know:
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {m.related.map((q) => (
                          <button
                            key={q}
                            onClick={() => send(q)}
                            className="rounded-full border border-border px-3 py-1 text-xs text-muted-foreground transition-colors hover:bg-accent hover:text-accent-foreground"
                          >
                            → {q}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  {settings.showAnalysis && <AIAnalysis analysis={m.analysis} />}
                </>
              )}
            </div>
            {m.role === "user" && (
              <span className="mt-1 grid size-8 shrink-0 place-items-center rounded-xl bg-secondary">
                <User className="size-4 text-secondary-foreground" />
              </span>
            )}
          </div>
        ))}

        {typing && (
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <span className="grid size-8 place-items-center rounded-xl bg-hero-gradient">
              <Bot className="size-4 text-primary-foreground" />
            </span>
            <span className="flex gap-1">
              {[0, 1, 2].map((i) => (
                <span
                  key={i}
                  className="size-2 animate-bounce rounded-full bg-primary"
                  style={{ animationDelay: `${i * 120}ms` }}
                />
              ))}
            </span>
          </div>
        )}
        <div ref={endRef} />
      </div>

      <form
        className="flex items-end gap-2 py-4"
        onSubmit={(e) => {
          e.preventDefault();
          send(input);
        }}
      >
        <Textarea
          ref={inputRef}
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter" && !e.shiftKey) {
              e.preventDefault();
              send(input);
            }
          }}
          rows={1}
          placeholder={voice.listening ? "Listening…" : "Ask a question in your own words…"}
          className="min-h-11 resize-none"
        />
        {voice.supported && (
          <Button
            type="button"
            variant={voice.listening ? "secondary" : "outline"}
            size="lg"
            onClick={voice.toggle}
            aria-label={voice.listening ? "Stop listening" : "Ask by voice"}
          >
            {voice.listening ? <MicOff className="size-4" /> : <Mic className="size-4" />}
          </Button>
        )}
        <Button type="submit" disabled={!input.trim() || typing} size="lg">
          <Send className="size-4" />
        </Button>
        {lastUserQuery && !typing && (
          <Button
            type="button"
            variant="outline"
            size="lg"
            onClick={() => send(lastUserQuery, true)}
            aria-label="Regenerate last answer"
          >
            <RefreshCw className="size-4" />
          </Button>
        )}
      </form>
    </div>
  );
}
